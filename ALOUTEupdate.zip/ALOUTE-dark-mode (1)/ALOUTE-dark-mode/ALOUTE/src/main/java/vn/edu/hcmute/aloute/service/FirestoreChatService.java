package vn.edu.hcmute.aloute.service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.cloud.firestore.Firestore;
import com.google.firebase.FirebaseApp;
import com.google.firebase.cloud.FirestoreClient;

import vn.edu.hcmute.aloute.dto.DirectMessageView;

/**
 * Đồng bộ tin nhắn trực tiếp sang Cloud Firestore (collection "messages").
 * Chạy bất đồng bộ và nuốt lỗi để Firebase gặp sự cố không làm hỏng chat.
 */
@Service
public class FirestoreChatService {

    private static final Logger log = LoggerFactory.getLogger(FirestoreChatService.class);
    private static final String COLLECTION = "messages";

    public void saveMessage(DirectMessageView view) {
        if (!enabled()) {
            return;
        }
        Map<String, Object> data = new HashMap<>();
        data.put("id", view.id());
        data.put("senderId", view.senderId());
        data.put("senderUsername", view.senderUsername());
        data.put("senderFullName", view.senderFullName());
        data.put("recipientId", view.recipientId());
        data.put("content", view.content());
        data.put("createdAt", view.createdAt());
        data.put("read", view.read());

        CompletableFuture.runAsync(() -> {
            try {
                db().collection(COLLECTION)
                    .document(String.valueOf(view.id()))
                    .set(data)
                    .get();
            } catch (Exception e) {
                log.warn("Không ghi được tin nhắn {} lên Firestore: {}", view.id(), e.getMessage());
            }
        });
    }

    public void deleteMessage(Long messageId) {
        if (!enabled()) {
            return;
        }
        CompletableFuture.runAsync(() -> {
            try {
                db().collection(COLLECTION)
                    .document(String.valueOf(messageId))
                    .delete()
                    .get();
            } catch (Exception e) {
                log.warn("Không xóa được tin nhắn {} trên Firestore: {}", messageId, e.getMessage());
            }
        });
    }

    private boolean enabled() {
        return !FirebaseApp.getApps().isEmpty();
    }

    private Firestore db() {
        return FirestoreClient.getFirestore();
    }
}
