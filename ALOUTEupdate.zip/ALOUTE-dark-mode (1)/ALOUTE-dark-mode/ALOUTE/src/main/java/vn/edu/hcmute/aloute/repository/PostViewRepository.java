package vn.edu.hcmute.aloute.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import vn.edu.hcmute.aloute.entity.PostView;

public interface PostViewRepository extends JpaRepository<PostView, Long> {
    boolean existsByPostIdAndViewerId(Long postId, Long viewerId);
}