package vn.edu.hcmute.aloute.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import vn.edu.hcmute.aloute.entity.FcmToken;
import vn.edu.hcmute.aloute.entity.UserAccount;

public interface FcmTokenRepository extends JpaRepository<FcmToken, Long> {

    List<FcmToken> findByUser(UserAccount user);

    Optional<FcmToken> findByToken(String token);
}