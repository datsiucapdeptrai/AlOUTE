package vn.edu.hcmute.aloute.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import vn.edu.hcmute.aloute.service.AccountService;


@Controller
@RequiredArgsConstructor
public class AccountController {
    private final AccountService accountService;

    @GetMapping("/account/settings")
    public String settings() { return "account/settings"; }

    @PostMapping("/account/password")
    public String changePassword(@RequestParam String currentPassword,
                                 @RequestParam String newPassword,
                                 @RequestParam String confirmPassword,
                                 Authentication auth, RedirectAttributes ra) {
        try {
            accountService.changePassword(auth.getName(), currentPassword, newPassword, confirmPassword);
            ra.addFlashAttribute("success", "Đổi mật khẩu thành công");
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
        }
        return "redirect:/account/settings";
    }

    @PostMapping("/account/delete")
    public String delete(@RequestParam String password, Authentication auth,
                         HttpServletRequest req, HttpServletResponse res, RedirectAttributes ra) {
        try {
            accountService.deleteAccount(auth.getName(), password);
        } catch (IllegalArgumentException e) {
            ra.addFlashAttribute("error", e.getMessage());
            return "redirect:/account/settings";
        }
        new SecurityContextLogoutHandler().logout(req, res, auth);
        Cookie c = new Cookie("jwt_token", null);
        c.setPath("/");
        c.setMaxAge(0);
        res.addCookie(c);
        return "redirect:/login?deleted";
    }
}