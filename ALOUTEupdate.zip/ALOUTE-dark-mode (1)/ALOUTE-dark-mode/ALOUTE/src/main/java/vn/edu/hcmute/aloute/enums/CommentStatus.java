package vn.edu.hcmute.aloute.enums;

public enum CommentStatus {

    ACTIVE,     // Bình luận đang hiển thị
    HIDDEN,     // Manager hoặc Admin đã ẩn
    DELETED     // Người dùng đã xóa
}