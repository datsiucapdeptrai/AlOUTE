package vn.edu.hcmute.aloute.enums;

public enum PostStatus {

    ACTIVE,     // Bài viết đang hiển thị
    HIDDEN,     // Manager hoặc Admin đã ẩn
    DELETED     // Người dùng đã xóa
}