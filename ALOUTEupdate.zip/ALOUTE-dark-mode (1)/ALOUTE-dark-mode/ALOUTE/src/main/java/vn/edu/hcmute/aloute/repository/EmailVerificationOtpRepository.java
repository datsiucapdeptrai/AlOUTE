package vn.edu.hcmute.aloute.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

import vn.edu.hcmute.aloute.entity.EmailVerificationOtp;
import vn.edu.hcmute.aloute.entity.UserAccount;

public interface EmailVerificationOtpRepository
        extends JpaRepository<EmailVerificationOtp, Long> {

    Optional<EmailVerificationOtp> findByUser(UserAccount user);

    void deleteAllByUser(UserAccount user);
}
