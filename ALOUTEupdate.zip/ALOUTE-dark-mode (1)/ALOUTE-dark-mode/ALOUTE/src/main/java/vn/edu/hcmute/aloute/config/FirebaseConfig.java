package vn.edu.hcmute.aloute.config;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

import jakarta.annotation.PostConstruct;

/**
 * Khởi tạo Firebase Admin SDK để dùng Cloud Firestore (gói Spark miễn phí).
 * Không dùng Cloud Storage nên không cần gói Blaze.
 */
@Configuration
public class FirebaseConfig {

    private static final Logger log = LoggerFactory.getLogger(FirebaseConfig.class);

    @Value("${firebase.credentials-path}")
    private String credentialsPath;

    @PostConstruct
    public void init() throws IOException {
        if (!FirebaseApp.getApps().isEmpty()) {
            return;
        }
        Path keyFile = Paths.get(credentialsPath);
        if (!Files.exists(keyFile)) {
            log.warn("Không tìm thấy file key Firebase tại '{}'. Bỏ qua Firestore, ứng dụng vẫn chạy bình thường.",
                    credentialsPath);
            return;
        }
        try (InputStream in = Files.newInputStream(keyFile)) {
            FirebaseOptions options = FirebaseOptions.builder()
                .setCredentials(GoogleCredentials.fromStream(in))
                .build();
            FirebaseApp.initializeApp(options);
            log.info("Đã kết nối Firebase (Firestore).");
        }
    }
}
