package vn.edu.hcmute.aloute.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;
import vn.edu.hcmute.aloute.entity.UserAccount;
import vn.edu.hcmute.aloute.enums.AccountStatus;
import vn.edu.hcmute.aloute.repository.UserAccountRepository;


@Service
@RequiredArgsConstructor
public class AccountService {
	private final UserAccountRepository userRepo;
	private final PasswordEncoder encoder;

	@Transactional
	public void changePassword(String username, String current, String next, String confirm) {
		UserAccount u = userRepo.findByUsernameIgnoreCase(username)
				.orElseThrow(() -> new IllegalArgumentException("Không tìm thấy người dùng"));
		if (!encoder.matches(current, u.getPasswordHash()))
			throw new IllegalArgumentException("Mật khẩu hiện tại không đúng");
		if (next == null || next.length() < 6)
			throw new IllegalArgumentException("Mật khẩu mới tối thiểu 6 ký tự");
		if (!next.equals(confirm))
			throw new IllegalArgumentException("Xác nhận mật khẩu không khớp");
		u.setPasswordHash(encoder.encode(next));
	}

	@Transactional
	public void deleteAccount(String username, String password) {
		UserAccount u = userRepo.findByUsernameIgnoreCase(username)
				.orElseThrow(() -> new IllegalArgumentException("Không tìm thấy người dùng"));
		if (!encoder.matches(password, u.getPasswordHash()))
			throw new IllegalArgumentException("Mật khẩu không đúng");
		u.setStatus(AccountStatus.DISABLED); // xóa mềm
	}
}