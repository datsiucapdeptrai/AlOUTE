package vn.edu.hcmute.aloute.enums;

public enum FriendshipStatus {

    PENDING,     // Đang chờ phản hồi
    ACCEPTED,    // Đã trở thành bạn bè
    REJECTED,    // Đã từ chối
    BLOCKED      // Đã chặn
}