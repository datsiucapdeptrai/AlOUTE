package vn.edu.hcmute.aloute.service;

import java.util.Locale;
import java.util.UUID;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseToken;

import lombok.RequiredArgsConstructor;
import vn.edu.hcmute.aloute.entity.Role;
import vn.edu.hcmute.aloute.entity.UserAccount;
import vn.edu.hcmute.aloute.entity.UserProfile;
import vn.edu.hcmute.aloute.enums.AccountStatus;
import vn.edu.hcmute.aloute.enums.RoleName;
import vn.edu.hcmute.aloute.repository.RoleRepository;
import vn.edu.hcmute.aloute.repository.UserAccountRepository;
@Service
@RequiredArgsConstructor
public class GoogleAuthService {

    private final UserAccountRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    @Transactional
    public UserAccount loginOrRegister(String idToken) throws FirebaseAuthException {
        if (FirebaseApp.getApps().isEmpty()) {
            throw new IllegalStateException("Firebase chưa được cấu hình trên server");
        }
        FirebaseToken token = FirebaseAuth.getInstance().verifyIdToken(idToken);
        if (token.getEmail() == null || !token.isEmailVerified()) {
            throw new IllegalArgumentException("Email Google chưa được xác thực");
        }
        String email = token.getEmail().toLowerCase(Locale.ROOT);

        return userRepository.findByEmailIgnoreCase(email)
            .map(u -> {
                if (u.getStatus() != AccountStatus.ACTIVE) {
                    throw new IllegalArgumentException("Tài khoản chưa kích hoạt hoặc đã bị khóa");
                }
                return u;
            })
            .orElseGet(() -> createFromGoogle(token, email));
    }

    private UserAccount createFromGoogle(FirebaseToken token, String email) {
        Role userRole = roleRepository.findByName(RoleName.ROLE_USER)
            .orElseThrow(() -> new IllegalStateException("Chưa có ROLE_USER"));

        UserAccount user = new UserAccount();
        user.setEmail(email);
        user.setUsername(uniqueUsername(email));
        user.setFullName(token.getName() != null ? token.getName() : email.split("@")[0]);
        // Tài khoản Google không dùng mật khẩu, đặt chuỗi ngẫu nhiên đã mã hóa
        user.setPasswordHash(passwordEncoder.encode(UUID.randomUUID().toString()));
        user.setStatus(AccountStatus.ACTIVE);
        user.addRole(userRole);
        user.setProfile(new UserProfile());
        return userRepository.saveAndFlush(user);
    }

    private String uniqueUsername(String email) {
        String base = email.split("@")[0].replaceAll("[^a-z0-9._]", "");
        if (base.length() > 40) base = base.substring(0, 40);
        if (base.isBlank()) base = "user";
        String candidate = base;
        int i = 1;
        while (userRepository.existsByUsernameIgnoreCase(candidate)) {
            candidate = base + i++;
        }
        return candidate;
    }
}