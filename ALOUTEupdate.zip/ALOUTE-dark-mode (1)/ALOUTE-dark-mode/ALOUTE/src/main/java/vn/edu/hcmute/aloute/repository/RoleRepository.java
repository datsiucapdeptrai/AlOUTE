package vn.edu.hcmute.aloute.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

import vn.edu.hcmute.aloute.entity.Role;
import vn.edu.hcmute.aloute.enums.RoleName;

public interface RoleRepository extends JpaRepository<Role, Long> {
    Optional<Role> findByName(RoleName name);
}