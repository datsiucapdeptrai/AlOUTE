package vn.edu.hcmute.aloute.dto;

import lombok.Builder;
import lombok.Getter;
import vn.edu.hcmute.aloute.enums.FriendshipStatus;

@Getter
@Builder
public class FriendshipView {

    private Long friendshipId;
    private Long userId;
    private String username;
    private String fullName;
    private FriendshipStatus status;
    private boolean requestedByCurrentUser;
}