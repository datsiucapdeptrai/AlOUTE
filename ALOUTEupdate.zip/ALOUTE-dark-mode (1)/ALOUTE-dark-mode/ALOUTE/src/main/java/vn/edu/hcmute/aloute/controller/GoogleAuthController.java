package vn.edu.hcmute.aloute.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.firebase.auth.FirebaseAuthException;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import vn.edu.hcmute.aloute.entity.UserAccount;
import vn.edu.hcmute.aloute.security.CustomUserDetailsService;
import vn.edu.hcmute.aloute.service.GoogleAuthService;
import vn.edu.hcmute.aloute.service.JwtService;

@RestController
@RequiredArgsConstructor
public class GoogleAuthController {

    private final GoogleAuthService googleAuthService;
    private final JwtService jwtService;
    private final CustomUserDetailsService userDetailsService;

    public record GoogleLoginRequest(@NotBlank String idToken) {}

    @PostMapping("/auth/google")
    public ResponseEntity<Map<String, Object>> google(
            @Valid @RequestBody GoogleLoginRequest body,
            HttpServletRequest request,
            HttpServletResponse response) {
        try {
            UserAccount user = googleAuthService.loginOrRegister(body.idToken());
            UserDetails details = userDetailsService.loadUserByUsername(user.getUsername());

            Cookie cookie = new Cookie("jwt_token", jwtService.generateToken(details));
            cookie.setHttpOnly(true);
            cookie.setSecure(request.isSecure());
            cookie.setPath("/");
            cookie.setMaxAge((int) (jwtService.getExpirationTime() / 1000));
            response.addCookie(cookie);

            boolean admin = details.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
            return ResponseEntity.ok(Map.of("redirect", admin ? "/admin" : "/feed"));
        } catch (FirebaseAuthException | IllegalArgumentException | IllegalStateException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(Map.of("message", e.getMessage() == null ? "Đăng nhập thất bại" : e.getMessage()));
        }
    }
}