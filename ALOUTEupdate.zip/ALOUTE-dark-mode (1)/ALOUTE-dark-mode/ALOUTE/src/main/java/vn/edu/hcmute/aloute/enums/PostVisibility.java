package vn.edu.hcmute.aloute.enums;

public enum PostVisibility {

    PUBLIC,     // Công khai
    FRIENDS,    // Chỉ bạn bè
    PRIVATE     // Chỉ mình tôi
}