package vn.edu.hcmute.aloute.controller;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;
import vn.edu.hcmute.aloute.service.FcmService;

@RestController
@RequiredArgsConstructor
public class FcmController {

    private final FcmService fcmService;

    @PostMapping("/fcm/token")
    public ResponseEntity<Void> register(@RequestBody Map<String, String> body,
                                         Authentication authentication) {
        String token = body.get("token");
        if (token == null || token.isBlank() || token.length() > 500) {
            return ResponseEntity.badRequest().build();
        }
        fcmService.saveToken(authentication.getName(), token);
        return ResponseEntity.ok().build();
    }

    /** Trang chẩn đoán tạm thời: mở http://localhost:8080/fcm/test khi đã đăng nhập. */
    @GetMapping("/fcm/test")
    public ResponseEntity<Map<String, Object>> test(Authentication authentication) {
        return ResponseEntity.ok(fcmService.diagnose(authentication.getName()));
    }
}