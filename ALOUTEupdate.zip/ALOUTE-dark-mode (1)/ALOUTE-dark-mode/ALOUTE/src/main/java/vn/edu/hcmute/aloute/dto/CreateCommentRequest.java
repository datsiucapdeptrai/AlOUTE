package vn.edu.hcmute.aloute.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class CreateCommentRequest {

    @NotBlank(message = "Bình luận không được để trống")
    @Size(
        max = 2000,
        message = "Bình luận không được quá 2000 ký tự"
    )
    private String content;
    private Long parentId;

    public Long getParentId() { return parentId; }
    public void setParentId(Long parentId) { this.parentId = parentId; }
}