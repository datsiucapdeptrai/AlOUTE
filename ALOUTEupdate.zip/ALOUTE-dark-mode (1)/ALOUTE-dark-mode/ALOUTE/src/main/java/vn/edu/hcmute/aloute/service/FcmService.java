package vn.edu.hcmute.aloute.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.MessagingErrorCode;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import vn.edu.hcmute.aloute.entity.FcmToken;
import vn.edu.hcmute.aloute.entity.UserAccount;
import vn.edu.hcmute.aloute.repository.FcmTokenRepository;
import vn.edu.hcmute.aloute.repository.UserAccountRepository;

@Service
@RequiredArgsConstructor
@Slf4j
public class FcmService {

    private final FcmTokenRepository tokenRepository;
    private final UserAccountRepository userAccountRepository;

    @Transactional
    public void saveToken(String username, String token) {
        UserAccount user = userAccountRepository.findByUsernameIgnoreCase(username)
            .orElseThrow(() -> new IllegalStateException("Không tìm thấy người dùng"));

        FcmToken entity = tokenRepository.findByToken(token).orElseGet(() -> {
            FcmToken t = new FcmToken();
            t.setToken(token);
            return t;
        });
        entity.setUser(user);   // cùng trình duyệt đổi tài khoản thì token chuyển sang người mới
        tokenRepository.save(entity);
    }

    /** Chẩn đoán: gửi thử 1 push tới chính người dùng và trả về kết quả chi tiết. */
    @Transactional(readOnly = true)
    public Map<String, Object> diagnose(String username) {
        Map<String, Object> r = new LinkedHashMap<>();
        boolean init = !FirebaseApp.getApps().isEmpty();
        r.put("1_firebaseInitialized", init);
        if (!init) {
            r.put("ketLuan", "Server chua khoi tao Firebase: thieu file key (FIREBASE_KEY / C:/keys/firebase.json)");
            return r;
        }
        UserAccount user = userAccountRepository.findByUsernameIgnoreCase(username)
            .orElseThrow(() -> new IllegalStateException("Không tìm thấy người dùng"));
        List<FcmToken> tokens = tokenRepository.findByUser(user);
        r.put("2_username", user.getUsername());
        r.put("3_soTokenTrongDB", tokens.size());
        if (tokens.isEmpty()) {
            r.put("ketLuan", "Tai khoan nay chua luu token. Mo /feed, cho phep thong bao, xem Console co '[FCM] luu token ... 200' khong");
            return r;
        }
        List<String> results = new ArrayList<>();
        for (FcmToken t : tokens) {
            try {
                String id = FirebaseMessaging.getInstance().send(Message.builder()
                    .setToken(t.getToken())
                    .putData("title", "ALOUTE test")
                    .putData("body", "Neu thay thong bao nay la FCM hoat dong")
                    .putData("url", "/feed")
                    .build());
                results.add("OK " + id);
            } catch (FirebaseMessagingException e) {
                results.add("LOI " + e.getMessagingErrorCode() + ": " + e.getMessage());
            }
        }
        r.put("4_ketQuaGui", results);
        return r;
    }

    @Transactional
    public void push(UserAccount recipient, String title, String body, String url) {
        if (FirebaseApp.getApps().isEmpty()) {
            log.warn("FCM bỏ qua: Firebase chưa khởi tạo (thiếu file key firebase.json?)");
            return;
        }

        List<FcmToken> tokens = tokenRepository.findByUser(recipient);
        log.info("FCM: gửi tới {} - có {} token", recipient.getUsername(), tokens.size());
        for (FcmToken t : tokens) {
            try {
                Message message = Message.builder()
                    .setToken(t.getToken())
                    .putData("title", title)
                    .putData("body", body)
                    .putData("url", url == null ? "/notifications" : url)
                    .build();
                String id = FirebaseMessaging.getInstance().send(message);
                log.info("FCM đã gửi: {}", id);

            } catch (FirebaseMessagingException e) {
                MessagingErrorCode code = e.getMessagingErrorCode();
                if (code == MessagingErrorCode.UNREGISTERED
                        || code == MessagingErrorCode.INVALID_ARGUMENT) {
                    tokenRepository.delete(t);      // token hết hạn thì xóa
                } else {
                    log.warn("Không gửi được FCM: {}", e.getMessage());
                }
            } catch (RuntimeException e) {
                log.warn("Lỗi FCM: {}", e.getMessage());
            }
        }
    }
}