package vn.edu.hcmute.aloute.enums;

public enum RoleName {
    ROLE_GUEST,
    ROLE_USER,
    ROLE_MANAGER,
    ROLE_ADMIN
}