package vn.edu.hcmute.aloute.controller;

import org.springframework.data.domain.Page;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import lombok.RequiredArgsConstructor;
import vn.edu.hcmute.aloute.entity.Post;
import vn.edu.hcmute.aloute.service.PostLikeService;
import vn.edu.hcmute.aloute.service.PostService;

@Controller
@RequiredArgsConstructor
public class HomeController {

    private final PostService postService;
    private final PostLikeService postLikeService;

    @GetMapping("/")
    public String home(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "") String keyword,
            @RequestParam(defaultValue = "ALL") String type,
            @RequestParam(defaultValue = "popular") String sort,
            Authentication authentication,
            Model model) {

        // Đã đăng nhập -> về bảng tin
        if (authentication != null && authentication.isAuthenticated()
                && !(authentication instanceof AnonymousAuthenticationToken)) {
            return "redirect:/feed";
        }

        Page<Post> posts = postService.searchPublicPosts(keyword, type, sort, page);

        model.addAttribute("posts", posts);
        model.addAttribute("keyword", keyword);
        model.addAttribute("type", type);
        model.addAttribute("sort", sort);
        model.addAttribute("likeCounts", postLikeService.getLikeCounts(posts.getContent()));
        model.addAttribute("reactionStats", postLikeService.getReactionStats(posts.getContent()));
        return "index";
    }
}