package vn.edu.hcmute.aloute.enums;

public enum AccountStatus {
    ACTIVE,
    LOCKED,
    DISABLED
}