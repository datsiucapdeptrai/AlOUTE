package vn.edu.hcmute.aloute.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import vn.edu.hcmute.aloute.entity.Notification;
import vn.edu.hcmute.aloute.entity.UserAccount;
import vn.edu.hcmute.aloute.enums.NotificationType;

public interface NotificationRepository
        extends JpaRepository<Notification, Long> {

    @EntityGraph(attributePaths = "actor")
    Page<Notification> findByRecipientOrderByCreatedAtDesc(
        UserAccount recipient,
        Pageable pageable
    );

    @EntityGraph(attributePaths = "actor")
    Page<Notification> findByRecipientAndReadFalseOrderByCreatedAtDesc(
        UserAccount recipient,
        Pageable pageable
    );

    @EntityGraph(attributePaths = "actor")
    Page<Notification> findByRecipientAndTypeOrderByCreatedAtDesc(
        UserAccount recipient,
        NotificationType type,
        Pageable pageable
    );

    List<Notification> findByRecipientAndReadFalse(
        UserAccount recipient
    );

    long countByRecipientAndReadFalse(
        UserAccount recipient
    );
}