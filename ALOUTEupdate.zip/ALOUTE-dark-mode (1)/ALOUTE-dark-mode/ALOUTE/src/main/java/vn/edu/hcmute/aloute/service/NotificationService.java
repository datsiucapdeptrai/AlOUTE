package vn.edu.hcmute.aloute.service;

import java.util.List;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;
import vn.edu.hcmute.aloute.dto.NotificationMessage;
import vn.edu.hcmute.aloute.entity.Notification;
import vn.edu.hcmute.aloute.entity.UserAccount;
import vn.edu.hcmute.aloute.enums.NotificationType;
import vn.edu.hcmute.aloute.repository.NotificationRepository;
import vn.edu.hcmute.aloute.repository.UserAccountRepository;

@Service
@RequiredArgsConstructor
public class NotificationService {
    private final FcmService fcmService;
    private static final int PAGE_SIZE = 15;

    private final NotificationRepository notificationRepository;

    private final UserAccountRepository userAccountRepository;

    private final SimpMessagingTemplate messagingTemplate;

    @Transactional
    public void sendNotification(
            UserAccount actor,
            UserAccount recipient,
            NotificationType type,
            String message,
            Long referenceId,
            String targetUrl) {

        if (actor.getId().equals(recipient.getId())) {
            return;
        }
       
        // Người nhận đã tắt thông báo -> không tạo thông báo mới
        if (Boolean.TRUE.equals(recipient.getNotificationsMuted())) {
            return;
        }

        Notification notification = new Notification();

        notification.setActor(actor);
        notification.setRecipient(recipient);
        notification.setType(type);
        notification.setMessage(message);
        notification.setReferenceId(referenceId);
        notification.setTargetUrl(targetUrl);
        notification.setRead(false);

        Notification saved =
            notificationRepository.save(notification);

        long unreadCount =
            notificationRepository
                .countByRecipientAndReadFalse(recipient);

        NotificationMessage socketMessage =
            new NotificationMessage(
                saved.getId(),
                type.name(),
                message,
                targetUrl,
                unreadCount
            );

        messagingTemplate.convertAndSendToUser(
            recipient.getUsername(),
            "/queue/notifications",
            socketMessage
        );
        fcmService.push(
                recipient,
                "ALOUTE",
                actor.getFullName() + " " + message,
                targetUrl
            );
    }

    @Transactional(readOnly = true)
    public Page<Notification> getNotifications(
            String username,
            int page,
            String filter) {

        UserAccount user = findUser(username);
        PageRequest pageRequest =
            PageRequest.of(Math.max(page, 0), PAGE_SIZE);

        if ("UNREAD".equalsIgnoreCase(filter)) {
            return notificationRepository
                .findByRecipientAndReadFalseOrderByCreatedAtDesc(
                    user, pageRequest);
        }

        if (filter != null
                && !filter.isBlank()
                && !"ALL".equalsIgnoreCase(filter)) {
            try {
                NotificationType type =
                    NotificationType.valueOf(filter.toUpperCase());
                return notificationRepository
                    .findByRecipientAndTypeOrderByCreatedAtDesc(
                        user, type, pageRequest);
            } catch (IllegalArgumentException ignored) {
                // filter không hợp lệ -> trả về tất cả
            }
        }

        return notificationRepository
            .findByRecipientOrderByCreatedAtDesc(user, pageRequest);
    }
   
    @Transactional(readOnly = true)
    public long getUnreadCount(String username) {

        UserAccount user = findUser(username);

        return notificationRepository
            .countByRecipientAndReadFalse(user);
    }

    @Transactional
    public String markAsRead(
            Long notificationId,
            String username) {

        Notification notification = notificationRepository
            .findById(notificationId)
            .orElseThrow(() ->
                new IllegalArgumentException(
                    "Không tìm thấy thông báo"
                )
            );

        if (!notification.getRecipient()
                .getUsername()
                .equalsIgnoreCase(username)) {

            throw new AccessDeniedException(
                "Bạn không có quyền xem thông báo này"
            );
        }

        notification.setRead(true);

        String targetUrl = notification.getTargetUrl();

        if (targetUrl == null
                || !targetUrl.startsWith("/")
                || targetUrl.startsWith("//")) {

            return "/notifications";
        }

        return targetUrl;
    }

    @Transactional
    public void markAllAsRead(String username) {

        UserAccount user = findUser(username);

        List<Notification> notifications =
            notificationRepository
                .findByRecipientAndReadFalse(user);

        notifications.forEach(
            notification -> notification.setRead(true)
        );
    }

    @Transactional
    public void delete(Long notificationId, String username) {

        Notification notification = notificationRepository
            .findById(notificationId)
            .orElseThrow(() ->
                new IllegalArgumentException(
                    "Không tìm thấy thông báo"
                )
            );

        if (!notification.getRecipient()
                .getUsername()
                .equalsIgnoreCase(username)) {

            throw new AccessDeniedException(
                "Bạn không có quyền xóa thông báo này"
            );
        }

        notificationRepository.delete(notification);
    }

    @Transactional
    public boolean toggleMute(String username) {

        UserAccount user = findUser(username);

        boolean muted =
            !Boolean.TRUE.equals(user.getNotificationsMuted());

        user.setNotificationsMuted(muted);
        return muted;
    }

    private UserAccount findUser(String username) {

        return userAccountRepository
            .findByUsernameIgnoreCase(username)
            .orElseThrow(() ->
                new IllegalStateException(
                    "Không tìm thấy người dùng"
                )
            );
    }
}