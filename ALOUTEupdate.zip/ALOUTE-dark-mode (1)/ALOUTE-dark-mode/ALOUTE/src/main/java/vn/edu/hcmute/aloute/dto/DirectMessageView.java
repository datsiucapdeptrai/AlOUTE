package vn.edu.hcmute.aloute.dto;

public record DirectMessageView(
    Long id,
    Long senderId,
    String senderUsername,
    String senderFullName,
    Long recipientId,
    String content,
    String createdAt,
    boolean read
) {
}