	package vn.edu.hcmute.aloute.controller;

import java.security.Principal;
import java.util.Map;

import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import lombok.RequiredArgsConstructor;
import vn.edu.hcmute.aloute.entity.UserAccount;
import vn.edu.hcmute.aloute.enums.FriendshipStatus;
import vn.edu.hcmute.aloute.repository.FriendshipRepository;
import vn.edu.hcmute.aloute.repository.UserAccountRepository;
@Controller
@RequiredArgsConstructor
public class CallSignalController {
    private final SimpMessagingTemplate messagingTemplate;
    private final UserAccountRepository userAccountRepository;
    private final FriendshipRepository friendshipRepository;

    @MessageMapping("/call/{toUsername}")
    public void signal(@DestinationVariable String toUsername,
                       @Payload Map<String, Object> payload,
                       Principal principal) {
        UserAccount me = userAccountRepository.findByUsernameIgnoreCase(principal.getName()).orElseThrow();
        UserAccount other = userAccountRepository.findByUsernameIgnoreCase(toUsername).orElseThrow();
        Long one = Math.min(me.getId(), other.getId());
        Long two = Math.max(me.getId(), other.getId());
        boolean friends = friendshipRepository.findByUserOneIdAndUserTwoId(one, two)
            .filter(f -> f.getStatus() == FriendshipStatus.ACCEPTED).isPresent();
        if (!friends) return;

        payload.put("from", me.getUsername());
        messagingTemplate.convertAndSendToUser(other.getUsername(), "/queue/call", payload);
    }
}