package vn.edu.hcmute.aloute.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import lombok.RequiredArgsConstructor;
import vn.edu.hcmute.aloute.security.CustomAuthenticationFailureHandler;
import vn.edu.hcmute.aloute.security.JwtAuthenticationFilter;
import vn.edu.hcmute.aloute.security.LoginSuccessHandler;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

	private final LoginSuccessHandler loginSuccessHandler;
	private final JwtAuthenticationFilter jwtAuthenticationFilter;
	private final CustomAuthenticationFailureHandler failureHandler;

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http.csrf(csrf -> csrf.ignoringRequestMatchers("/auth/google", "/ws/**"))
				.authorizeHttpRequests(auth -> auth.requestMatchers("/", "/login", "/register", "/verify", "/verify/**",
						"/forgot-password", "/reset-password", "/reset-password/**", "/auth/google",
						"/firebase-messaging-sw.js", "/css/**", "/js/**", "/images/**",
						"/uploads/**", "/error", "/ws/**" // ✅ Cho phép WebSocket handshake + SockJS fallback
				).permitAll().requestMatchers("/admin/**").hasRole("ADMIN").requestMatchers("/manager/**")
						.hasAnyRole("MANAGER", "ADMIN").anyRequest().authenticated())
				.sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED))
				.formLogin(form -> form.loginPage("/login").loginProcessingUrl("/login").usernameParameter("username")
						.passwordParameter("password").successHandler(loginSuccessHandler).failureHandler(failureHandler)
						.permitAll())
				.logout(logout -> logout.logoutUrl("/logout").logoutSuccessUrl("/login?logout")
						.deleteCookies("jwt_token").permitAll())
				.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

		return http.build();
	}
}