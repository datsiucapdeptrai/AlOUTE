package vn.edu.hcmute.aloute.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import vn.edu.hcmute.aloute.entity.UserReport;

public interface UserReportRepository extends JpaRepository<UserReport, Long> {
}