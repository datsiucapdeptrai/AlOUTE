package vn.edu.hcmute.aloute.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

import vn.edu.hcmute.aloute.entity.PasswordResetOtp;
import vn.edu.hcmute.aloute.entity.UserAccount;

public interface PasswordResetOtpRepository
        extends JpaRepository<PasswordResetOtp, Long> {

    Optional<PasswordResetOtp> findByUser(UserAccount user);

    void deleteAllByUser(UserAccount user);
}
