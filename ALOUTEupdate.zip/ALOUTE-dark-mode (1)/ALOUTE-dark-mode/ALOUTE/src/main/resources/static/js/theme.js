
(function () {
    var KEY = "aloute-theme";
    var root = document.documentElement;
    var media = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null;

    function stored() {
        try { var v = localStorage.getItem(KEY); return v === "dark" || v === "light" ? v : null; }
        catch (e) { return null; }
    }
    function current() { return stored() || (media && media.matches ? "dark" : "light"); }

    function apply(theme) {
        root.setAttribute("data-bs-theme", theme);
        var btn = document.getElementById("themeToggleBtn");
        if (btn) {
            var dark = theme === "dark";
            btn.textContent = dark ? "☀️" : "🌙";
            btn.title = dark ? "Chuyển sang chế độ sáng" : "Chuyển sang chế độ tối";
            btn.setAttribute("aria-label", btn.title);
            btn.setAttribute("aria-pressed", String(dark));
        }
    }

    function set(theme) {
        try { localStorage.setItem(KEY, theme); } catch (e) { /* bỏ qua */ }
        apply(theme);
    }

    apply(current());

    // Theo hệ điều hành khi người dùng chưa tự chọn
    if (media) {
        var onChange = function () { if (!stored()) apply(current()); };
        if (media.addEventListener) media.addEventListener("change", onChange);
        else if (media.addListener) media.addListener(onChange);
    }
    // Đồng bộ giữa các tab
    window.addEventListener("storage", function (e) { if (e.key === KEY) apply(current()); });

    document.addEventListener("DOMContentLoaded", function () {
        if (document.getElementById("themeToggleBtn")) return;
        var btn = document.createElement("button");
        btn.id = "themeToggleBtn";
        btn.type = "button";
        btn.className = "theme-toggle-btn";
        btn.addEventListener("click", function () {
            set(root.getAttribute("data-bs-theme") === "dark" ? "light" : "dark");
        });
        document.body.appendChild(btn);
        apply(current());
    });

    window.AlouteTheme = { get: current, set: set };
})();
