// Service worker xử lý push trực tiếp (không dùng Firebase SDK trong SW).
// Lý do: SDK chỉ gọi onBackgroundMessage khi KHÔNG có tab nào của site đang hiển thị;
// nếu có tab đang mở mà không có listener (vd /messages, /fcm/test) thì tin bị nuốt mất.
self.addEventListener("install", function () {
    self.skipWaiting();
});

self.addEventListener("activate", function (event) {
    event.waitUntil(self.clients.claim());
});

self.addEventListener("push", function (event) {
    let d = {};
    try {
        const payload = event.data ? event.data.json() : {};
        d = payload.data || payload.notification || payload || {};
    } catch (e) {
        d = {};
    }
    event.waitUntil(
        self.registration.showNotification(d.title || "ALOUTE", {
            body: d.body || "",
            data: { url: d.url || "/notifications" }
        })
    );
});

self.addEventListener("notificationclick", function (event) {
    event.notification.close();
    const url = (event.notification.data && event.notification.data.url) || "/";
    event.waitUntil(
        clients.matchAll({ type: "window", includeUncontrolled: true }).then(function (list) {
            for (const c of list) {
                if ("focus" in c) { c.navigate(url); return c.focus(); }
            }
            return clients.openWindow(url);
        })
    );
});