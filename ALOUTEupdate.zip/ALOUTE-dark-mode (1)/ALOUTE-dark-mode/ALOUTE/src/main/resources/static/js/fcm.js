(function () {
    if (!("serviceWorker" in navigator) || !("Notification" in window)
            || typeof firebase === "undefined") return;

    firebase.initializeApp({
        apiKey: "AIzaSyAs4rGDaeQ4BZAMKEPqPyW0COyhWmUAdTY",
        authDomain: "webcuoiki-117dc.firebaseapp.com",
        projectId: "webcuoiki-117dc",
        messagingSenderId: "684427505919",
        appId: "1:684427505919:web:4255bb028da16e39111cca"
    });
    const messaging = firebase.messaging();
    const VAPID_KEY = "BIejLg9VZYZ0rcZcdq8GhVeViuK5VMf3SllspVd7ZOe2nETFhyGAZRGWXiw0qtrlvbkV7w20rS-2g95x0A_SoL4";
    const btn = document.getElementById("enablePushBtn");

    async function registerPush() {
        const reg = await navigator.serviceWorker.register("/firebase-messaging-sw.js");
        await navigator.serviceWorker.ready;
        const token = await messaging.getToken({
            vapidKey: VAPID_KEY,
            serviceWorkerRegistration: reg
        });
        console.log("[FCM] token:", token);
        if (!token) { console.warn("[FCM] Không lấy được token"); return; }

        const res = await fetch("/fcm/token", {
            method: "POST",
            headers: { "Content-Type": "application/json", ...csrfHeaders() },
            body: JSON.stringify({ token: token })
        });
        console.log("[FCM] lưu token lên server:", res.status);

        if (btn) btn.classList.add("d-none");
    }

    console.log("[FCM] quyền thông báo:", Notification.permission);
    if (Notification.permission === "denied") {
        console.warn("[FCM] Bị chặn thông báo. Bấm ổ khóa cạnh thanh địa chỉ để cho phép lại.");
    }
    if (Notification.permission === "granted") {
        registerPush().catch(console.error);
    } else if (Notification.permission === "default" && btn) {
        btn.classList.remove("d-none");
        btn.addEventListener("click", async function (e) {
            e.preventDefault();
            e.stopPropagation();
            const p = await Notification.requestPermission();
            if (p === "granted") registerPush().catch(console.error);
        });
    }
})();