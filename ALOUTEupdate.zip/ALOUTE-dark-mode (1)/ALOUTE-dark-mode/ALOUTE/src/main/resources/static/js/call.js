(function () {
    const cfg = { iceServers: [{ urls: "stun:stun.l.google.com:19302" }] };
	let pc = null, localStream = null, peer = null, pending = [];

	async function flushPending() {
	    for (const c of pending) {
	        try { await pc.addIceCandidate(c); } catch (err) { console.warn(err); }
	    }
	    pending = [];
	}

	function send(to, data) {
	    window.ALOUTEStomp.publish({
	        destination: "/app/call/" + to,
	        headers: { "content-type": "application/json" },
	        body: JSON.stringify(data)
	    });
	}

    async function setup(to) {
        peer = to;
        localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        document.getElementById("localVideo").srcObject = localStream;
        pc = new RTCPeerConnection(cfg);
        localStream.getTracks().forEach(t => pc.addTrack(t, localStream));
        pc.ontrack = e => document.getElementById("remoteVideo").srcObject = e.streams[0];
        pc.onicecandidate = e => { if (e.candidate) send(peer, { type: "candidate", candidate: e.candidate }); };
        document.getElementById("callBox").classList.remove("d-none");
    }

    function hangup(notify) {
        if (notify && peer) send(peer, { type: "hangup" });
        if (pc) pc.close();
        if (localStream) localStream.getTracks().forEach(t => t.stop());
		pc = null; localStream = null; peer = null; pending = [];
        document.getElementById("callBox").classList.add("d-none");
    }

	window.startCall = async function (toUsername) {
	    if (pc) return;   // đang trong cuộc gọi thì bỏ qua
	    try {
	        await setup(toUsername);
	        const offer = await pc.createOffer();
	        await pc.setLocalDescription(offer);
	        send(peer, { type: "offer", sdp: offer });
	    } catch (err) {
	        console.error(err);
	        alert("Không mở được camera/micro: " + err.message);
	        hangup(false);
	    }
	};

	window.addEventListener("ALOUTE:call-signal", async function (e) {
	    const m = e.detail;
	    try {
	        if (m.type === "offer") {
	            if (pc) {                       // đang bận máy
	                send(m.from, { type: "reject" });
	                return;
	            }
	            if (!confirm(m.from + " đang gọi video cho bạn. Nghe máy?")) {
	                send(m.from, { type: "reject" });
	                return;
	            }
	            await setup(m.from);
	            await pc.setRemoteDescription(m.sdp);
	            await flushPending();
	            const answer = await pc.createAnswer();
	            await pc.setLocalDescription(answer);
	            send(peer, { type: "answer", sdp: answer });
	        } else if (m.type === "answer" && pc) {
	            await pc.setRemoteDescription(m.sdp);
	            await flushPending();
	        } else if (m.type === "candidate") {
	            if (pc && pc.remoteDescription) {
	                await pc.addIceCandidate(m.candidate);
	            } else {
	                pending.push(m.candidate);   // chưa sẵn sàng thì cất lại
	            }
	        } else if (m.type === "reject" || m.type === "hangup") {
	            hangup(false);
	        }
	    } catch (err) {
	        console.error(err);
	        alert("Không thực hiện được cuộc gọi: " + err.message);
	        hangup(false);
	    }
	});

    document.getElementById("hangupButton").addEventListener("click", () => hangup(true));
    document.getElementById("chatCallButton").addEventListener("click", function () {
        const name = document.getElementById("chatPartnerName").textContent;
        // activeFriend nằm trong feed-chat.js; nếu bạn expose window.activeFriend thì dùng username ở đó
        if (window.activeFriend && window.activeFriend.username) window.startCall(window.activeFriend.username);
        else alert("Hãy mở cuộc trò chuyện với bạn bè trước khi gọi (" + name + ")");
    });
})();