# Tích hợp Firebase (Cloud Firestore, gói Spark miễn phí)

Tin nhắn trực tiếp (DirectMessage) được đồng bộ sang Firestore, collection `messages`
(document id = id tin nhắn). Gửi tin -> ghi, xóa tin -> xóa. Ảnh/video/avatar lưu local trong `uploads/`.
Không dùng Cloud Storage nên không cần gói Blaze.

## Cài đặt
1. https://console.firebase.google.com -> chọn project -> **Build > Firestore Database > Create database**
   (chọn Standard, location gần nhất, Start in **production mode**).
2. **Project settings > Service accounts > Generate new private key** -> lưu file JSON, ví dụ `C:/keys/firebase.json`.
3. Đặt biến môi trường `FIREBASE_KEY` trỏ tới file đó (hoặc để đúng `C:/keys/firebase.json`).
   Không commit file key lên Git.
4. Chạy ứng dụng, đăng nhập, nhắn tin cho bạn bè -> xem dữ liệu ở Firestore > collection `messages`.

Nếu không có file key, ứng dụng vẫn chạy bình thường và chỉ ghi log cảnh báo.
